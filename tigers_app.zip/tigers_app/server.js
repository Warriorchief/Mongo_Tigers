var express=require('express')
var mongoose=require('mongoose')
var path=require('path')
var bodyParser=require('body-parser')
var app = express();
mongoose.connect('mongodb://localhost/tigers');
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, './views'));
app.use(express.static(path.join(__dirname, './static')));
app.use(bodyParser.urlencoded({ extended: true }));


var TigerSchema = new mongoose.Schema({
 name: String,
 location: String,
 prey: String
})
var Tiger = mongoose.model('Tiger',TigerSchema)

app.get('/', function(req, res){ //displays all of the tigers on the index page
    Tiger.find({}, function(err,data){
      if (err){
        console.log("there was an error");
        res.send(err);
        console.log(err);
      }
      else{
        console.log("loading the index page");
        /*console.log(data);*/
        res.render('index',{tigers:data});
      }
    })
  })

app.get('/new', function(req,res){
  console.log("loading the new tiger page");
  res.render('addnew');
})

app.post('/addnew', function(req, res) {
  console.log("posting the new tiger data to make a new tiger");
  console.log("POST DATA", req.body);
  var new_tiger = new Tiger(req.body);
  new_tiger.save(function(err) {
    if(err) {
      console.log('something went wrong');
    } else {
      console.log('successfully added a tiger!');
      res.redirect('/');
    }
  })
})

app.get('/info/:guy', function(req, res){
  Tiger.find({_id:req.params.guy}, function(err,data){
    if (err){
      console.log("there was an error")
      res.send(err);
      console.log(err);
    }
    else{
      res.render('infopage',{this_tiger:data});
    }
  })
})

app.get('/tigers/edit/:guy', function(req,res){
  console.log("getting the edit page for this particular tiger");
  Tiger.find({_id:req.params.guy},function(err,data){
    if (err){
      console.log("there was an error");
    }
    else{
      console.log("have located the tiger's data and it is:");
      console.log(data);
      console.log("going to packege this as a dictionary object in this way: {this_tiger}")
      res.render('edit',{this_tiger:data});
    }
  })
})

//_____________________________________________________


app.post('/tigers/update/:guy', function(req,res){
  console.log("updating this particular tiger through post");
  console.log("POST DATA",req.body);
  Tiger.update({_id:req.params.guy},{name:req.body.name,location:req.body.location,prey:req.body.prey},function(err){
    if(err){
      console.log("there was an error");
    }
    else{
      res.redirect('/');
    }
  })
})


app.post('/tigers/destroy/:cat', function(req,res){
  Tiger.remove({_id:req.params.cat}, function(err){
    if (err){
      console.log("something went wrong")
    }
    else{
      console.log('successfully removed a tiger!')
      res.redirect('/');
    }
  })
})

app.listen(8000, function() {
    console.log("listening on port 8000");
})
